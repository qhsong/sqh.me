#include "StdAfx.h"
#include "CommonFun.h"
SOCKET initSocket(HWND hWnd,int iport,char *pServerAddr){		//��������˽�������
	SOCKET s;
	s=socket(AF_INET,SOCK_STREAM,0);
	if(s==INVALID_SOCKET){
		MessageBox(hWnd,"�޷�����socket","ERROR",MB_OK);
		return SOCKET_ERROR;
	}
	sockaddr_in servAddr;	//������addr
	ZeroMemory(&servAddr,sizeof servAddr);
	servAddr.sin_family=AF_INET;
	servAddr.sin_port=htons(iport);
	servAddr.sin_addr.S_un.S_addr=inet_addr(pServerAddr);
	if(connect(s,(sockaddr*)&servAddr,sizeof servAddr)==SOCKET_ERROR){
		MessageBox(hWnd,"connectʧ��","ERROR",MB_OK);
		return SOCKET_ERROR;
	}
	return s;
}

BOOL Login_Server(HWND hMain,HWND hListBox,SOCKET s,char *username,int iUtype){
	myMSG first_msg,*recvM;
	char buff[256],recvbuffer[512];
	char *pch;
	SYSTEMTIME st;
	first_msg.MsgHead.dwId=CMD_LOGIN;
	first_msg.MsgHead.dwLength=sizeof MSG_HEAD+sizeof MSG_LOGIN;
	lstrcpy(first_msg.Login.szUsername,username);
	first_msg.Login.wUserType=iUtype;
	first_msg.Login.iCount=lstrlen(username);
	pch=(char *)&first_msg;
	if(send(s,pch,first_msg.MsgHead.dwLength,0)==SOCKET_ERROR){
		MessageBox(hMain,"send���ݰ�ʧ��","ERROR",MB_OK);
		return 1;
	}
	pch=recvbuffer;
	if(recv(s,pch,sizeof MSG_HEAD+sizeof MSG_LOGIN_RESP,0)==SOCKET_ERROR){
		MessageBox(hMain,"recv���ݰ�ʧ��","ERROR",MB_OK);
		return 1;
	}
	recvM=(myMSG *)pch;
	if(recvM->LoginResp.wbReturn==TRUE){
		GetLocalTime(&st);
		wsprintf(buff,"%02d:%02d:%02d ��½�ɹ���%s %s ��ӭ��",
		st.wHour,st.wMinute,st.wSecond,iUtype==1?"������":"������",username);
		SendMessage(hListBox,LB_ADDSTRING,NULL,(LPARAM)buff);
	}
	return 0;
}

int ExitServer(SOCKET s,int iUtype){
	char *pch;
	myMSG myMsg;
	myMsg.MsgHead.dwId=CMD_EXIT;
	myMsg.MsgHead.dwLength=sizeof MSG_HEAD+sizeof MSG_EXIT;
	myMsg.msgExitCode.wExit=1;
	myMsg.msgExitCode.wUserType=iUtype;
	pch=(char *)&myMsg;
	send(s,pch,myMsg.MsgHead.dwLength,0);
	return 0;
}


BOOL RecvPacket(SOCKET hSocket,char *lpBuffer,UINT dwSize){
	BOOL bReturn=TRUE;
	int iRemain;
	myMSG *pMSG;
	char *lpContent;
	pMSG=(myMSG *)lpBuffer;
	if(!RecvData(hSocket,lpBuffer,sizeof MSG_HEAD)){		//�������ݰ�ͷ��
		if(pMSG->MsgHead.dwLength>=sizeof MSG_HEAD && pMSG->MsgHead.dwLength<=dwSize){
			iRemain=pMSG->MsgHead.dwLength-sizeof MSG_HEAD;
			if (iRemain>0){
				lpContent=(char *)((UINT)lpBuffer+sizeof MSG_HEAD);
				if(!RecvData(hSocket,lpContent,iRemain))	//�������ݰ�ʣ�ಿ��
					bReturn=FALSE;
			}
			else
				bReturn=FALSE;
		}
	}
	return bReturn;
}

int RecvData(SOCKET hSocket,char* lpData,UINT dwSize){
	int iErrFlag=0;
	int dwRemain,iSocketCount,iRecvCount;
	char *pCh;
	pCh=lpData;
	dwRemain=dwSize;
	while(TRUE){
		iSocketCount=WaitData(hSocket);
		if (iSocketCount==SOCKET_ERROR)
		{
			iErrFlag=1;
			break;
		}
		if(iSocketCount==0)
			continue;
		iRecvCount=recv(hSocket,pCh,dwRemain,0);
		if (iRecvCount==SOCKET_ERROR || iRecvCount==0){		//������߽�����
				iErrFlag=1;
				break;
		}
		if(iRecvCount<dwRemain){		//û�н�����
			pCh+=iRecvCount;
			dwRemain-=iRecvCount;
		}
		else
			break;
	}
	return iErrFlag;
}

int WaitData(SOCKET hSocket){
	INT fdCount;
	fd_set stFdset;
	timeval stTimeval;
	FD_ZERO(&stFdset);
	stFdset.fd_array[0]=hSocket;
	stFdset.fd_count=1;
	stTimeval.tv_sec=0;
	stTimeval.tv_usec=10000*1000;
	fdCount=select(0,&stFdset,NULL,NULL,&stTimeval);
	return fdCount;
}