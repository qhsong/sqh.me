// producer.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <WINSOCK2.H>
#include <TIME.H>
#pragma comment(lib, "ws2_32.lib")
#include "../Message.h"
#include "../CommonFun.h"
#include <stdio.h>

#define MAX_LOADSTRING 100
#define SERVER_PORT 9999
#define SERVER_ADDRESS "127.0.0.1"

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
HWND hMain;
HWND hListBox,hUsername,hButtonLogin,hButtonPut,hEditText;		//���ִ��ڱ���
HMENU hMenu;
SOCKET sToSer;
char szResource[512][256];
int iFileCount;
// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
BOOL  SendtoServer(SOCKET s,HWND hList,char *pString);
void readResource();
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_PRODUCER, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_PRODUCER);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_PRODUCER);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_PRODUCER;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
	static char szUsername[30];
	static SOCKET s;
	static BOOL bChecked;
	static char szProduct[512];
	static char szPrintUser[20]={"�û���"};

	switch (message) 
	{
		case WM_CREATE:
			hUsername=CreateWindow("EDIT",,"�������û���",WS_CHILD|WS_VISIBLE|WS_BORDER,
				50,5,150,20,hWnd,(HMENU)1,hInst,NULL);
			hListBox=CreateWindow("LISTBOX","message",WS_CHILD|WS_VISIBLE|
				LBS_STANDARD|WS_DISABLED,5,35,400,250,hWnd,(HMENU)2,hInst,NULL);
			hButtonLogin=CreateWindow("BUTTON","��½",WS_CHILD|WS_VISIBLE|WS_BORDER,
				210,0,50,30,hWnd,(HMENU)3,hInst,NULL);
			hEditText=CreateWindow("EDIT","������������������",WS_CHILD|WS_VISIBLE
				|WS_BORDER|WS_DISABLED,5,280,250,20,hWnd,(HMENU)4,hInst,NULL);
			hButtonPut=CreateWindow("BUTTON","����",WS_CHILD|WS_VISIBLE
				|WS_DISABLED,260,280,40,20,hWnd,(HMENU)5,hInst,NULL);
			MoveWindow(hWnd,0,0,450,400,FALSE);
			hMain=hWnd;
			WORD wVersionRequested;
			WSADATA wsadata;
			hMain=hWnd;
			wVersionRequested= MAKEWORD(2,0);
			WSAStartup(wVersionRequested,&wsadata);
			hMenu=GetMenu(hWnd);
			EnableMenuItem(hMenu,IDM_AUTO,MF_DISABLED|MF_GRAYED);
			readResource();
			srand((unsigned)time(NULL));
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			if(wmId==3){			//��½�˵�����
				if(wmEvent==BN_CLICKED){
					GetWindowText(hUsername,szUsername,sizeof szUsername);
					if(!lstrlen(szUsername)){
						MessageBox(hWnd,"�������û���","ERROR",MB_OK);
						return 0;
					}
					if((s=initSocket(hWnd,SERVER_PORT,SERVER_ADDRESS))==SOCKET_ERROR){
						MessageBox(hWnd,"�����������ʧ��","ERROR",MB_OK);
						return 0;
					}
					if(!Login_Server(hWnd,hListBox,s,szUsername,1)){
						EnableWindow(hListBox,TRUE);
						EnableWindow(hEditText,TRUE);
						EnableWindow(hButtonPut,TRUE);
						EnableWindow(hUsername,FALSE);
						EnableWindow(hButtonLogin,FALSE);
						EnableMenuItem(hMenu,IDM_AUTO,MF_ENABLED);
						}
					}
				return 0;
			}
			if(wmId==5){
				if(wmEvent==BN_CLICKED){
					GetWindowText(hEditText,szProduct,sizeof szProduct);
					if(!lstrlen(szProduct)){
						MessageBox(hWnd,"������Ʒ��Ч","ERROR",MB_OK);
						return 0;
					}
					SendtoServer(s,hListBox,szProduct);
				}
			}
				switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case IDM_AUTO:
					if(bChecked==FALSE){
						CheckMenuItem(hMenu,IDM_AUTO,MF_CHECKED);
						bChecked=TRUE;
						SetTimer(hWnd,7,1000,NULL);
						//things to do
					}else{
						CheckMenuItem(hMenu,IDM_AUTO,MF_UNCHECKED);
						KillTimer(hWnd,7);
						bChecked=FALSE;
					}
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_TIMER:
				int isend;
				//MessageBox(hWnd,"call WM_TIMER","debug",MB_OK);
				isend=rand()%iFileCount;
				SendtoServer(s,hListBox,szResource[isend]);
				break;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
// 			RECT rt;
// 			GetClientRect(hWnd, &rt);
// 			DrawText(hdc, szHello, strlen(szHello), &rt, DT_CENTER);
// 			EndPaint(hWnd, &ps);
			TextOut(hdc,0,5,szPrintUser,lstrlen(szPrintUser));
			break;
		case WM_DESTROY:
			ExitServer(s,1);
			closesocket(s);
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

BOOL  SendtoServer(SOCKET s,HWND hList,char *pString){
		myMSG sendmsg;
		char *pCh;
		char szBuff[256];
		SYSTEMTIME st;
		sendmsg.MsgHead.dwId=CMD_PUT;
		lstrcpy(sendmsg.PutMessage.szContent,pString);
		sendmsg.PutMessage.dwLength=lstrlen(pString);
		sendmsg.MsgHead.dwLength=sizeof MSG_HEAD+sizeof MSG_PUT;
		pCh=(char *)&sendmsg;
		if(send(s,pCh,sendmsg.MsgHead.dwLength,0)!=SOCKET_ERROR){
			GetLocalTime(&st);
			wsprintf(szBuff,"%02d:%02d:%02d �ͳ���Ʒ:%s",
				st.wHour,st.wMinute,st.wSecond,pString);
			SendMessage(hList,LB_ADDSTRING,NULL,(LPARAM)szBuff);
		}
		return FALSE;
}

void readResource(){	// ��ȡ�ļ�
	HANDLE hfile;
	hfile=CreateFile("resource.txt",GENERIC_READ,FILE_SHARE_READ,NULL,
		OPEN_EXISTING,0,NULL);
	if(hfile!=INVALID_HANDLE_VALUE){
		char filebuffer[256];
		BOOL bResult=TRUE;
		unsigned long read=1;
		while(bResult&&read!=0){
			bResult=ReadFile(hfile,filebuffer,256,&read,NULL);
			for(int i=0,j=0;i<256;i++){
				if(filebuffer[i]!=13)
					szResource[iFileCount][j]=filebuffer[i];
				else{
					szResource[iFileCount][j]='\0';
					i++;	//ȥ�����з�
					iFileCount++;
					j=0;
					continue;
				}
			j++;
			}
		}
	}
	return;
}