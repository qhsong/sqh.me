// service.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <TIME.H>

#include "../Message.h"
#include "../CommonFun.h"

#define MAX_LOADSTRING 100
#define PORT 9999
#define MAX_BUFF 15
#define ID_TIMER 3
typedef struct tagBuffer{
	HBRUSH bhr;
	char content[256];
}Buffer;

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
int g_iProduCount,g_iConsuCount;
HWND hwMain,hwMessage;
SOCKET hListenSocket;
HANDLE hSIsPut,hSB1NULL,hSB1FULL,hSB2NULL,hSB2FULL,hSIsGet;	//�ź���
int iflag[3][MAX_BUFF];
Buffer buffer1[MAX_BUFF],buffer2[MAX_BUFF],buffer3[MAX_BUFF];		//3��buffer
CRITICAL_SECTION csPut,csMove1,csMove2,csGet;
int g_iCount[3];//buffer����
// 
// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
unsigned __stdcall ListenThread(void *pM);
unsigned __stdcall ServiceThread(void *pM);
void Put(char *szString);
unsigned __stdcall move1(void *pM);
void move(Buffer *buffDest,Buffer *buffRes);
void printbuff(HDC hdc);
unsigned __stdcall move2(void *pM);
void printbuff(HDC hdc);
void get(char *szretuns);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_SERVICE, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_SERVICE);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_SERVICE);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
	char buffer[256];
	static int i=0;

	switch (message) 
	{
		case WM_CREATE:
			hwMain=hWnd;
			WORD wVersoinRequested;
			WSADATA wsadata;
			wVersoinRequested=MAKEWORD(1,1);
			if (WSAStartup(wVersoinRequested,&wsadata))
			{
				MessageBox(hWnd,"Windows Socket��ʼ��ʧ��","ERROR",MB_OK);
				return FALSE;
			}
			hwMessage=CreateWindow("LISTBOX","",WS_CHILD|WS_VISIBLE|LBS_STANDARD
				|LBS_NOSEL|WS_BORDER,5,60,400,250,hWnd,(HMENU)2,hInst,NULL);
			_beginthreadex(NULL,0,ListenThread,NULL,NULL,NULL);
			MoveWindow(hWnd,0,0,1000,400,FALSE);
			hSIsPut=CreateSemaphore(NULL,15,MAX_BUFF,NULL);		//��ʼ���ź���
			hSB1NULL=CreateSemaphore(NULL,0,MAX_BUFF,NULL);
			hSB1FULL=CreateSemaphore(NULL,15,MAX_BUFF,NULL);
			hSB2NULL=CreateSemaphore(NULL,0,MAX_BUFF,NULL);
			hSB2FULL=CreateSemaphore(NULL,15,MAX_BUFF,NULL);
			hSIsGet=CreateSemaphore(NULL,0,MAX_BUFF,NULL);
			InitializeCriticalSection(&csGet);			//	��ʼ���ٽ���
			InitializeCriticalSection(&csMove1);
			InitializeCriticalSection(&csMove2);
			InitializeCriticalSection(&csPut);
			for (i=0;i<MAX_BUFF;i++){
				iflag[0][i]=iflag[1][i]=iflag[2][i]=0;
			}
			srand((unsigned int)time(NULL));
			g_iCount[0]=g_iCount[1]=g_iCount[2]=0;
			SetTimer(hWnd,ID_TIMER,1000,NULL);
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			break;
		case WM_TIMER:
 			if(g_iCount[0]!=0){
 				_beginthreadex(NULL,0,move1,NULL,NULL,NULL);
 			}
			if(g_iCount[1]!=0)
				_beginthreadex(NULL,0,move2,NULL,NULL,NULL);
 			RECT rect;
 			SetRect(&rect,430,5,980,360);
 			InvalidateRect(hWnd,&rect,TRUE);
 			//wsprintf(szConsoleBuff,"WM_TIME��Ӧ\n");
 			//WriteConsole(hConsole,szConsoleBuff,strlen(szConsoleBuff),NULL,NULL);
			break;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			i++;
			wsprintf(buffer,"��ǰ��������������Ϊ%d",g_iProduCount);
			TextOut(hdc,5,5,buffer,lstrlen(buffer));
			wsprintf(buffer,"��ǰ��������������Ϊ%d",g_iConsuCount);
			TextOut(hdc,5,30,buffer,lstrlen(buffer));
			wsprintf(buffer,"��ǰ��������%d",i);
			//SendMessage(hwMessage,LB_ADDSTRING,NULL,(LPARAM)buffer);
			// TODO: Add any drawing code here...
// 			RECT rt;
// 			GetClientRect(hWnd, &rt);
// 			DrawText(hdc, szHello, strlen(szHello), &rt, DT_CENTER);
			printbuff(hdc);
			EndPaint(hWnd, &ps);
			break;
		case WM_DESTROY:
			KillTimer(hWnd,ID_TIMER);
			FreeConsole();
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}


unsigned __stdcall ListenThread(void *pM){
	SOCKADDR_IN acc_sin;
	SOCKADDR_IN stSin;
	SOCKET s;
	int iLength;
//	UINT dwThreadId;
	HANDLE hThread;
	hListenSocket = socket(AF_INET,SOCK_STREAM,0);
	RtlZeroMemory(&stSin,sizeof stSin);
	stSin.sin_port=htons(PORT);
	stSin.sin_addr.s_addr=INADDR_ANY;
	stSin.sin_family=AF_INET;
	iLength=sizeof stSin;
	if(bind(hListenSocket,(PSOCKADDR)&stSin,sizeof stSin)){
		MessageBox(NULL,"�׽��ְ�ʧ��","ERROR",MB_OK);
		return 0;
	}
	if(listen(hListenSocket,10)){
		MessageBox(NULL,"�׽�������ʧ��","ERROR",MB_OK);
		return 0;
	}
	while (TRUE){
		s=accept(hListenSocket,(PSOCKADDR)&acc_sin,&iLength);
		if (s==INVALID_SOCKET){
			MessageBox(NULL,"�׽���acceptʧ��","ERROR",MB_OK);
			return 0;
		}
		hThread=(HANDLE)_beginthreadex(NULL,0,ServiceThread,(PVOID)s,NULL,NULL);
		CloseHandle(hThread);
	}
	closesocket(hListenSocket);
}

unsigned __stdcall ServiceThread(void *pM){
	SOCKET hSocket;
	//SESSION stSession;
	hSocket = (SOCKET)pM;
	myMSG *pMsg;
	char Buffer[512];
	BOOL bResult;
	char username[256];
	int iResult;
	char szTextBuffer[512];
	WORD wUserType;
	char szBuff[512];
	SYSTEMTIME st;
	while(TRUE){
		bResult=RecvPacket(hSocket,Buffer,sizeof Buffer);
		if(bResult==0){
			pMsg=(myMSG *)Buffer;
			if(pMsg->MsgHead.dwId == CMD_LOGIN){
				lstrcpy(username,pMsg->Login.szUsername);
				username[pMsg->Login.iCount]='\0';
				wUserType=pMsg->Login.wUserType;
				pMsg->LoginResp.wbReturn=TRUE;
				pMsg->MsgHead.dwId=CMD_LOGIN_RESP;
				pMsg->MsgHead.dwLength=sizeof MSG_HEAD+sizeof MSG_LOGIN_RESP;
				iResult=send(hSocket,Buffer,pMsg->MsgHead.dwLength,0);
				if(iResult!=SOCKET_ERROR){
					GetLocalTime(&st);
					wsprintf(szTextBuffer,"%02d:%02d:%02d %s %s ��½ϵͳ",
						st.wHour,st.wMinute,st.wSecond,wUserType==1?"������":"������",username);
					SendMessage(hwMessage,LB_ADDSTRING,NULL,(LPARAM)szTextBuffer);
					wUserType==1?g_iProduCount++:g_iConsuCount++;
					InvalidateRect(hwMain,NULL,FALSE);
				}
			}
			if(pMsg->MsgHead.dwId== CMD_EXIT && pMsg->msgExitCode.wExit==1){
				GetLocalTime(&st);
				wsprintf(szTextBuffer,"%02d:%02d:%02d %s %s �˳���ϵͳ",
					st.wHour,st.wMinute,st.wSecond,wUserType==1?"������":"������",username);
				SendMessage(hwMessage,LB_ADDSTRING,NULL,(LPARAM)szTextBuffer);
				wUserType=pMsg->msgExitCode.wUserType;
				wUserType==1?g_iProduCount--:g_iConsuCount--;
				InvalidateRect(hwMain,NULL,FALSE);
				_endthread();
			}
			if (pMsg->MsgHead.dwId==CMD_PUT){
				pMsg->PutMessage.szContent[pMsg->PutMessage.dwLength]='\0';
				lstrcpy(szBuff,pMsg->PutMessage.szContent);
				GetLocalTime(&st);
				wsprintf(szTextBuffer,"%02d:%02d:%02d %s������%s",
					st.wHour,st.wMinute,st.wSecond,username,szBuff);
				SendMessage(hwMessage,LB_ADDSTRING,NULL,(LPARAM)szTextBuffer);
				Put(szBuff);
			}
			if(pMsg->MsgHead.dwId==CMD_GET&&pMsg->GetMessage.bGet==TRUE){
				char szGetBuff[256];
				get(szGetBuff);
				char *pCh;
				pMsg->MsgHead.dwId=CMD_PUT;
				lstrcpy(pMsg->PutMessage.szContent,szGetBuff);
				pMsg->PutMessage.dwLength = lstrlen(szGetBuff);
				pMsg->MsgHead.dwLength = sizeof MSG_HEAD +sizeof MSG_PUT;
				pCh=(char *)pMsg;
				send(hSocket,pCh,pMsg->MsgHead.dwLength,0);
			}
		}
	}
	return 0;
}

void Put(char *szString){
	WaitForSingleObject(hSIsPut,INFINITE);
	EnterCriticalSection(&csPut);
	int i=0;
	long sign;
	HBRUSH hbrnow;
	for(i=0 ; i<MAX_BUFF ; i++){		//��λ��
		if(iflag[0][i]==0){
			break;	
		}
	}
	hbrnow=CreateSolidBrush(RGB(rand()%200+55,rand()%200+55,rand()%200+55));
	buffer1[i].bhr=hbrnow;
	lstrcpy(buffer1[i].content,szString);
	iflag[0][i]=1;
	g_iCount[0]++;
	LeaveCriticalSection(&csPut);
	ReleaseSemaphore(hSB1NULL,1,&sign);
}

unsigned __stdcall move1(void *pM){
	WaitForSingleObject(hSB1NULL,INFINITE);
	WaitForSingleObject(hSB1FULL,INFINITE);
	EnterCriticalSection(&csMove1);
		int i,ib1,ib2;
		for(i=0;i<MAX_BUFF;i++){	//b1��Ԫ��
			if(iflag[0][i]){
				ib1=i;
				break;
			}
		}
		for (i=0;i<MAX_BUFF;i++){	//b2��
			if(!iflag[1][i]){
				ib2=i;
				break;
			}
		}
		move(&buffer2[ib2],&buffer1[ib1]);
		iflag[0][ib1]=0;
		iflag[1][ib2]=1;
		g_iCount[0]--;
		g_iCount[1]++;
	LeaveCriticalSection(&csMove1);
	ReleaseSemaphore(hSIsPut,1,NULL);
	ReleaseSemaphore(hSB2NULL,1,NULL);
	return 0;
}

void move(Buffer *buffDest,Buffer *buffRes){		//�ƶ�Ԫ�أ���resource�ƶ���bufferdest
		buffDest->bhr=buffRes->bhr;
		lstrcpy(buffDest->content,buffRes->content);
		return;
}

unsigned __stdcall move2(void *pM){
	WaitForSingleObject(hSB2FULL,INFINITE);
	WaitForSingleObject(hSB2NULL,INFINITE);
	EnterCriticalSection(&csMove2);
	int i,ib2,ib3;
	for(i=0;i<MAX_BUFF;i++){	//b2��Ԫ��
		if(iflag[1][i]){
			ib2=i;
			break;
		}
	}
	for (i=0;i<MAX_BUFF;i++){	//b3��
		if(!iflag[2][i]){
			ib3=i;
			break;
		}
	}
	move(&buffer3[ib3],&buffer2[ib2]);
	iflag[1][ib2]=0;
	iflag[2][ib3]=1;
	g_iCount[1]--;
	g_iCount[2]++;
	LeaveCriticalSection(&csMove2);
	ReleaseSemaphore(hSB1FULL,1,NULL);
	ReleaseSemaphore(hSIsGet,1,NULL);
	return 0;
}

void get(char *szretuns){
	WaitForSingleObject(hSIsGet,INFINITE);
	EnterCriticalSection(&csPut);
	int i,ib3;
	for(i=0;i<MAX_BUFF;i++){
		if(iflag[2][i]){
			break;
		}
	}
	ib3=i;
	lstrcpy(szretuns,buffer3[ib3].content);
	iflag[2][ib3]=0;
	g_iCount[2]--;
	LeaveCriticalSection(&csPut);
	ReleaseSemaphore(hSB2FULL,1,NULL);
}

void printbuff(HDC hdc){
	int iStartx=430,iStarty=5,iEndx=980,iEndy=360,iGap=120;
	int iStartRectTop,iStartRectButtom;
	int iPerRectWidth=((iEndx-iStartx)/MAX_BUFF);
	char szbuffer[256],szbuff[3][50];
	int j;
	HBRUSH hOldbr,hWhiteBrush=CreateSolidBrush(RGB(255,255,255));
	//Rectangle(hdc,430,0,980,360);
	for(int i=0;i<3;i++){
		wsprintf(szbuff[i],"Buffer%d:      ʣ���Ѿ�ʹ������:%d",i+1,g_iCount[i]);
		TextOut(hdc,iStartx,iStarty+iGap*i,szbuff[i],lstrlen(szbuff[i]));
		//Rectangle(hdc,iStartx,iStarty+20+iGap*i,iEndx,iGap+i*iGap);
	}
	for(i=0;i<3;i++){
		for(j=0;j<MAX_BUFF;j++){
			if(iflag[i][j]==0){
				hOldbr=(HBRUSH)SelectObject(hdc,hWhiteBrush);
			}else{
				if(i==0)
					hOldbr=(HBRUSH)SelectObject(hdc,buffer1[j].bhr);
				if(i==1)
					hOldbr=(HBRUSH)SelectObject(hdc,buffer2[j].bhr);
				if(i==2)
					hOldbr=(HBRUSH)SelectObject(hdc,buffer3[j].bhr);
			}
			Rectangle(hdc,iStartx+iPerRectWidth*j,iStarty+20+iGap*i,
				iStartx+iPerRectWidth*(j+1),iGap*(i+1));
			SelectObject(hdc,hOldbr);	//��ԭ��ˢ
		}
	}

}
