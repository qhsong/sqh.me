#if !defined(AFX_CommonFun_H__Message)
#define AFX_CommonFun_H__Message
#include <WINSOCK2.H>
#include <WINDOWS.H>
#include "Message.h"
SOCKET initSocket(HWND hWnd,int iport,char *pServerAddr);
BOOL Login_Server(HWND hMain,HWND hList,SOCKET s,char *username,int iUtype);
int ExitServer(SOCKET s,int);
BOOL RecvPacket(SOCKET hSocket,char *lpBuffer,UINT dwSize);
int RecvData(SOCKET hSocket,char* lpData,UINT dwSize);
int WaitData(SOCKET hSocket);
#endif