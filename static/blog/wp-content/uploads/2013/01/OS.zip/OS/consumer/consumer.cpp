// consumer.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <winsock2.h>
#include <PROCESS.H>
#pragma comment(lib, "ws2_32.lib")
#include "../Message.h"
#include "../CommonFun.h"

#define MAX_LOADSTRING 100
#define SERVICE_ADDRESS "127.0.0.1"
#define SERVICE_PORT 9999
// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
HMENU hMenu;
HWND hListBox,hUsername,hButtonLogin,hButtonGet;

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
void GetProduct(SOCKET s,char *szReturn);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_CONSUMER, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_CONSUMER);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_CONSUMER);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_CONSUMER;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
	static SOCKET s;
	static char szPrintUser[20]={"�û���"};
	static BOOL bChecked=FALSE;
	static char szUsername[20];
	static char szGetBuff[256];
	static char print[512];
	SYSTEMTIME st;
	switch (message) 
	{
		case WM_CREATE:
			hUsername=CreateWindow("EDIT",,"�������û���",WS_CHILD|WS_VISIBLE|WS_BORDER,
				50,5,150,20,hWnd,(HMENU)1,hInst,NULL);
			hListBox=CreateWindow("LISTBOX","message",WS_CHILD|WS_VISIBLE|
				WS_BORDER|LBS_NOSEL|WS_DISABLED,5,35,300,250,hWnd,(HMENU)2,hInst,NULL);
			hButtonLogin=CreateWindow("BUTTON","��½",WS_CHILD|WS_VISIBLE|WS_BORDER,
				210,0,50,30,hWnd,(HMENU)3,hInst,NULL);
			hButtonGet=CreateWindow("BUTTON","����",WS_CHILD|WS_VISIBLE|WS_BORDER|WS_DISABLED,
				310,35,50,245,hWnd,(HMENU)4,hInst,NULL);
			MoveWindow(hWnd,0,0,380,350,FALSE);
			WORD wVersionRequested;
			WSADATA wsadata;
			wVersionRequested= MAKEWORD(2,0);
			WSAStartup(wVersionRequested,&wsadata);
			hMenu=GetMenu(hWnd);
			EnableMenuItem(hMenu,IDM_AUTO,MF_DISABLED|MF_GRAYED);
			break;
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			if(wmId == 3){	//��¼��ť����
				if(wmEvent == BN_CLICKED){
					GetWindowText(hUsername,szUsername,sizeof szUsername);
					if(!lstrlen(szUsername)){
						MessageBox(hWnd,"�������û���","ERROR",MB_OK);
						return 0;
					}
					if((s=initSocket(hWnd,SERVICE_PORT,SERVICE_ADDRESS))==SOCKET_ERROR){
						MessageBox(hWnd,"�����������ʧ��","ERROR",MB_OK);
						return 0;
					}
					if(!Login_Server(hWnd,hListBox,s,szUsername,2)){
						EnableWindow(hListBox,TRUE);
						EnableWindow(hButtonGet,TRUE);
						EnableWindow(hUsername,FALSE);
						EnableWindow(hButtonLogin,FALSE);
						EnableMenuItem(hMenu,IDM_AUTO,MF_ENABLED);
					}
				}
			}
			if(wmId == 4){
				if(wmEvent == BN_CLICKED){
					GetProduct(s,szGetBuff);
					//_beginthreadex(NULL,)
					GetLocalTime(&st);
					wsprintf(print,"%02d:%02d:%02d �õ�����: %s",st.wHour,st.wMinute,st.wSecond,
						szGetBuff);
					SendMessage(hListBox,LB_ADDSTRING,NULL,(LPARAM)print);
				}
			}
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case IDM_AUTO:
					if(bChecked==FALSE){
						CheckMenuItem(hMenu,IDM_AUTO,MF_CHECKED);
						bChecked=TRUE;
						SetTimer(hWnd,5,1000,NULL);
					//things to do
					}else{
						CheckMenuItem(hMenu,IDM_AUTO,MF_UNCHECKED);
						bChecked=FALSE;
						KillTimer(hWnd,5);
					}
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			TextOut(hdc,0,5,szPrintUser,lstrlen(szPrintUser));
			EndPaint(hWnd, &ps);
			break;
		case WM_TIMER:
			GetProduct(s,szGetBuff);
			GetLocalTime(&st);
			wsprintf(print,"%02d:%02d:%02d �õ�����: %s",st.wHour,st.wMinute,st.wSecond,
				szGetBuff);
			SendMessage(hListBox,LB_ADDSTRING,NULL,(LPARAM)print);
			break;
		case WM_DESTROY:
			ExitServer(s,2);
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

void GetProduct(SOCKET s,char *szReturn){
	char *pCh;
	char buffer[512];
	BOOL bResult;
	myMSG mymsg,*pmyMsg;
	mymsg.MsgHead.dwId = CMD_GET;
	mymsg.MsgHead.dwLength = sizeof MSG_HEAD +sizeof MSG_GET;
	mymsg.GetMessage.bGet=TRUE;
	pCh = (char *)&mymsg;
	send(s,pCh,mymsg.MsgHead.dwLength,0);
	bResult=RecvPacket(s,buffer,sizeof buffer);
	if (bResult==0){
		pmyMsg=(myMSG *)buffer;
		pmyMsg->PutMessage.szContent[pmyMsg->PutMessage.dwLength]='\0';
		lstrcpy(szReturn,pmyMsg->PutMessage.szContent);
		return ;
	}
}
