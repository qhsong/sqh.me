// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_)
#define AFX_STDAFX_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_

#include <MALLOC.H>
#include <STDIO.H>
#include <STRING.H>
#include "Set.h"

typedef struct tag_NOTERMINAL_INDEX{
	int count;	//����
	int pos[256];	
}NOTERMIAL_INDEX;

enum BOOL {
	FALSE,TRUE
};

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_)
