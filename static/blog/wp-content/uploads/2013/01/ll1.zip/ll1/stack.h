#if !defined(AFX_stack_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_)
#define AFX_stack_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_
typedef struct tag_Stack{
	int top;
	char stack[256];

}Stack;

void push(Stack *s,char c);
char pop(Stack *s);
char gettop(Stack *s);
#endif