#if !defined(AFX_Set_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_)
#define AFX_Set_H__EF5CD445_15BD_4DDD_A4E5_08434ACE80E8__INCLUDED_

void TwoAND(char *source1,char *source2,char *out);
void DeleteOne(char *source,char c,char *out);
void twoOR(char *source1,char *source2,char *out);
#endif