#include "StdAfx.h"
#include "stack.h"
////��Ԫ��Cѹ��
void push(Stack *s,char c){
	s->stack[s->top++]=c;
}

char pop(Stack *s){
	return s->stack[s->top--];
}

char gettop(Stack *s){
	return s->stack[s->top-1];
}
